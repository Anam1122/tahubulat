// postcss.config.js
export default {
  plugins: {
    '@tailwindcss/postcss': {}, // INI YANG BENAR UNTUK TAILWIND CSS V4
    autoprefixer: {},
  },
};